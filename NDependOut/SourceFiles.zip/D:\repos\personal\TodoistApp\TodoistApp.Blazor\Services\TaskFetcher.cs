﻿namespace TodoistApp.Blazor.Services
{
    public class TaskFetcher
    {
        public int GetNumberOfTasks()
        {
            return 0;
        }
    }
}
